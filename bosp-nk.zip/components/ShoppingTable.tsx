'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { v4 as uuidv4 } from 'uuid';
import { Lock, Edit3, Eye, EyeOff, LogOut, Download, Filter, Trash2 } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ShoppingItem {
  id: string;
  order_number: number;
  item_name: string;
  quantity: string;
  class_name: string;
  notes: string;
  purchase_status: 'belum' | 'sudah';
}

interface LockedCell {
  id: string;
  field: string;
  userId: string;
}

export default function ShoppingTable({ initialEditMode }: { initialEditMode: boolean }) {
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [isEditMode, setIsEditMode] = useState(initialEditMode);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [lockedCells, setLockedCells] = useState<LockedCell[]>([]);
  const [filterStatus, setFilterStatus] = useState<'all' | 'belum' | 'sudah'>('all');
  const socketRef = useRef<Socket | null>(null);
  const [userId] = useState(() => uuidv4());
  const [activeCell, setActiveCell] = useState<{ id: string, field: string } | null>(null);

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io({
      path: '/api/socket',
    });

    socketRef.current = newSocket;

    newSocket.on('initial_data', (data: ShoppingItem[]) => {
      setItems(data);
    });

    newSocket.on('cell_updated', ({ id, field, value }) => {
      setItems((prev) => prev.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      ));
    });

    newSocket.on('row_added', (newRow: ShoppingItem) => {
      setItems((prev) => {
        if (prev.find(item => item.id === newRow.id)) return prev;
        // Sort by order_number to be safe
        const newItems = [...prev, newRow];
        return newItems.sort((a, b) => a.order_number - b.order_number);
      });
    });

    newSocket.on('cell_locked', (lock: LockedCell) => {
      setLockedCells((prev) => {
        const filtered = prev.filter(l => !(l.id === lock.id && l.field === lock.field));
        return [...filtered, lock];
      });
    });

    newSocket.on('cell_unlocked', ({ id, field }) => {
      setLockedCells((prev) => prev.filter(l => !(l.id === id && l.field === field)));
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      
      const data = await res.json();
      if (data.success) {
        setIsEditMode(true);
        setShowLoginModal(false);
        setPassword('');
      } else {
        setLoginError(data.message || 'Password salah');
      }
    } catch (err) {
      setLoginError('Terjadi kesalahan');
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/logout', { method: 'POST' });
      setIsEditMode(false);
      // Clear any active locks
      if (activeCell && socketRef.current) {
        socketRef.current.emit('unlock_cell', activeCell);
        setActiveCell(null);
      }
    } catch (err) {
      console.error('Logout failed', err);
    }
  };

  const handleCellFocus = (id: string, field: string) => {
    if (!isEditMode) return;
    
    // Check if cell is locked by someone else
    const isLocked = lockedCells.some(l => l.id === id && l.field === field && l.userId !== userId);
    if (isLocked) return;

    setActiveCell({ id, field });
    socketRef.current?.emit('lock_cell', { id, field, userId });
  };

  const handleCellBlur = (id: string, field: string) => {
    if (!isEditMode) return;
    
    if (activeCell?.id === id && activeCell?.field === field) {
      setActiveCell(null);
      socketRef.current?.emit('unlock_cell', { id, field });
    }
  };

  const handleCellChange = (id: string, field: keyof ShoppingItem, value: string) => {
    if (!isEditMode) return;

    // Optimistic update
    setItems((prev) => {
      return prev.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      );
    });

    // Emit to server
    socketRef.current?.emit('update_cell', { id, field, value });
    
    // Refresh lock timeout
    socketRef.current?.emit('lock_cell', { id, field, userId });
  };

  const isCellLockedByOther = (id: string, field: string) => {
    return lockedCells.some(l => l.id === id && l.field === field && l.userId !== userId);
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    
    doc.text('Daftar Belanja', 14, 15);
    
    const tableColumn = ["No", "Nama Barang", "Qty", "Kelas", "Keterangan", "Status"];
    const tableRows = filteredItems.map(item => [
      item.order_number,
      item.item_name,
      item.quantity,
      item.class_name,
      item.notes,
      item.purchase_status === 'sudah' ? 'Sudah Dibeli' : 'Belum Dibeli'
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save('daftar-belanja.pdf');
  };

  const filteredItems = items.filter(item => {
    if (filterStatus === 'all') return true;
    return item.purchase_status === filterStatus;
  });

  const [deleteConfirmation, setDeleteConfirmation] = useState<{ isOpen: boolean, type: 'single' | 'all', id?: string } | null>(null);
  const [deletePassword, setDeletePassword] = useState('');
  const [showDeletePassword, setShowDeletePassword] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  const handleDeleteRow = (id: string) => {
    if (!isEditMode) return;
    setDeleteConfirmation({ isOpen: true, type: 'single', id });
  };

  const handleDeleteAll = () => {
    if (!isEditMode || items.length === 0) return;
    setDeleteConfirmation({ isOpen: true, type: 'all' });
  };

  const confirmDelete = async () => {
    if (!deleteConfirmation) return;
    setDeleteError('');
    
    try {
      const res = await fetch('/api/delete-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: deletePassword }),
      });
      
      const data = await res.json();
      if (data.success) {
        if (deleteConfirmation.type === 'single' && deleteConfirmation.id) {
          socketRef.current?.emit('delete_item', { id: deleteConfirmation.id });
        } else if (deleteConfirmation.type === 'all') {
          socketRef.current?.emit('delete_all');
        }
        
        setDeleteConfirmation(null);
        setDeletePassword('');
      } else {
        setDeleteError(data.message || 'Password salah');
      }
    } catch (err) {
      setDeleteError('Terjadi kesalahan');
    }
  };

  return (
    <div className="flex flex-col w-full">
      {/* Toolbar */}
      <div className="flex justify-between items-center p-3 sm:p-4 border-b border-slate-200 bg-slate-50/50">
        <div className="text-sm text-slate-500 font-medium flex items-center gap-2">
          {isEditMode ? (
            <div className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto rounded-full bg-emerald-100 sm:bg-transparent" title="Mode Edit Aktif">
              <Edit3 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600" />
              <span className="hidden sm:inline ml-1">Mode Edit Aktif</span>
            </div>
          ) : (
            <div className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto rounded-full bg-slate-200 sm:bg-transparent" title="Mode Lihat (Read-only)">
              <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-slate-500" />
              <span className="hidden sm:inline ml-1">Mode Lihat (Read-only)</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto sm:px-4 sm:py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            title="Download PDF"
          >
            <Download className="w-4 h-4" /> <span className="hidden sm:inline ml-2">Download PDF</span>
          </button>
          
          {isEditMode && items.length > 0 && (
            <button
              onClick={handleDeleteAll}
              className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto sm:px-4 sm:py-2 text-sm font-medium text-white bg-red-600 border border-red-600 rounded-lg hover:bg-red-700 transition-colors"
              title="Hapus Semua"
            >
              <Trash2 className="w-4 h-4" /> <span className="hidden sm:inline ml-2">Hapus Semua</span>
            </button>
          )}

          <div className="relative flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto sm:px-3 sm:py-1.5 bg-white border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors">
            <Filter className="w-4 h-4 sm:mr-2 text-slate-500" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'all' | 'belum' | 'sudah')}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer sm:opacity-100 sm:relative sm:inset-auto sm:w-auto sm:h-auto sm:bg-transparent sm:outline-none sm:appearance-auto text-sm"
              title="Filter Status"
            >
              <option value="all">Semua</option>
              <option value="belum">Belum Dibeli</option>
              <option value="sudah">Sudah Dibeli</option>
            </select>
            {filterStatus !== 'all' && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full sm:hidden"></span>
            )}
          </div>

          {isEditMode ? (
            <button 
              onClick={handleLogout}
              className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto sm:px-4 sm:py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
              title="Keluar Mode Edit"
            >
              <LogOut className="w-4 h-4 text-red-500 sm:text-slate-700" /> <span className="hidden sm:inline ml-2">Keluar</span>
            </button>
          ) : (
            <button 
              onClick={() => setShowLoginModal(true)}
              className="flex items-center justify-center w-9 h-9 sm:w-auto sm:h-auto sm:px-4 sm:py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
              title="Masuk Mode Edit"
            >
              <Edit3 className="w-4 h-4" /> <span className="hidden sm:inline ml-2">Edit</span>
            </button>
          )}
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[600px]">
          <thead>
            <tr className="bg-slate-100/80 text-slate-600 text-[10px] sm:text-xs uppercase tracking-wider">
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold w-10 sm:w-12 text-center">No</th>
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold min-w-[150px] sm:min-w-[200px]">Nama Barang</th>
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold w-16 sm:w-24">Qty</th>
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold w-24 sm:w-32">Kelas</th>
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold min-w-[150px] sm:min-w-[200px]">Keterangan</th>
              <th className="p-2 sm:p-3 border-b border-r border-slate-200 font-semibold w-28 sm:w-40">Status</th>
              {isEditMode && (
                <th className="p-2 sm:p-3 border-b border-slate-200 font-semibold w-12 text-center">Aksi</th>
              )}
            </tr>
          </thead>
          <tbody className="text-xs sm:text-sm text-slate-800">
            {filteredItems.map((item, index) => (
              <tr key={item.id} className="border-b border-slate-200 hover:bg-slate-50/50 transition-colors">
                <td className="p-2 sm:p-3 border-r border-slate-200 text-center text-slate-500 font-mono">
                  {item.order_number}
                </td>
                <EditableCell 
                  value={item.item_name} 
                  field="item_name" 
                  item={item} 
                  isEditMode={isEditMode}
                  isLocked={isCellLockedByOther(item.id, 'item_name')}
                  onFocus={handleCellFocus}
                  onBlur={handleCellBlur}
                  onChange={handleCellChange}
                />
                <EditableCell 
                  value={item.quantity} 
                  field="quantity" 
                  item={item} 
                  isEditMode={isEditMode}
                  isLocked={isCellLockedByOther(item.id, 'quantity')}
                  onFocus={handleCellFocus}
                  onBlur={handleCellBlur}
                  onChange={handleCellChange}
                />
                <EditableCell 
                  value={item.class_name} 
                  field="class_name" 
                  item={item} 
                  isEditMode={isEditMode}
                  isLocked={isCellLockedByOther(item.id, 'class_name')}
                  onFocus={handleCellFocus}
                  onBlur={handleCellBlur}
                  onChange={handleCellChange}
                />
                <EditableCell 
                  value={item.notes} 
                  field="notes" 
                  item={item} 
                  isEditMode={isEditMode}
                  isLocked={isCellLockedByOther(item.id, 'notes')}
                  onFocus={handleCellFocus}
                  onBlur={handleCellBlur}
                  onChange={handleCellChange}
                />
                <td className="p-0 border-r border-slate-200 relative">
                  {isEditMode && !isCellLockedByOther(item.id, 'purchase_status') ? (
                    <select
                      value={item.purchase_status}
                      onChange={(e) => handleCellChange(item.id, 'purchase_status', e.target.value)}
                      onFocus={() => handleCellFocus(item.id, 'purchase_status')}
                      onBlur={() => handleCellBlur(item.id, 'purchase_status')}
                      className={`w-full h-full p-2 sm:p-3 bg-transparent outline-none cursor-pointer appearance-none font-medium text-xs sm:text-sm
                        ${item.purchase_status === 'sudah' ? 'text-emerald-600' : 'text-amber-600'}`}
                    >
                      <option value="belum">Belum Dibeli</option>
                      <option value="sudah">Sudah Dibeli</option>
                    </select>
                  ) : (
                    <div className="p-2 sm:p-3 flex items-center justify-between">
                      <span className={`inline-flex items-center px-2 py-0.5 sm:px-2.5 sm:py-0.5 rounded-full text-[10px] sm:text-xs font-medium
                        ${item.purchase_status === 'sudah' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                        {item.purchase_status === 'sudah' ? 'Sudah Dibeli' : 'Belum Dibeli'}
                      </span>
                      {isCellLockedByOther(item.id, 'purchase_status') && (
                        <Lock className="w-3 h-3 text-red-400" />
                      )}
                    </div>
                  )}
                </td>
                {isEditMode && (
                  <td className="p-2 sm:p-3 border-slate-200 text-center">
                    <button
                      onClick={() => handleDeleteRow(item.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      title="Hapus Baris"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                )}
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={isEditMode ? 7 : 6} className="p-8 text-center text-slate-500">
                  Memuat data...
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Masuk Mode Edit</h2>
              <p className="text-slate-500 text-sm mb-6">Masukkan password untuk mengedit daftar belanja.</p>
              
              <form onSubmit={handleLogin}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-slate-900 outline-none transition-all pr-10"
                      placeholder="Masukkan password..."
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {loginError && <p className="text-red-500 text-xs mt-2">{loginError}</p>}
                </div>
                
                <div className="flex justify-end gap-3 mt-8">
                  <button
                    type="button"
                    onClick={() => {
                      setShowLoginModal(false);
                      setLoginError('');
                      setPassword('');
                      setShowPassword(false);
                    }}
                    className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
                  >
                    Masuk
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation?.isOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Konfirmasi Hapus</h2>
              <p className="text-slate-500 text-sm mb-6">
                {deleteConfirmation.type === 'all' 
                  ? 'Apakah Anda yakin ingin menghapus SEMUA barang dari daftar belanja? Tindakan ini tidak dapat dibatalkan.' 
                  : 'Apakah Anda yakin ingin menghapus barang ini?'}
              </p>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-1">Password Hapus</label>
                <div className="relative">
                  <input
                    type={showDeletePassword ? "text" : "password"}
                    value={deletePassword}
                    onChange={(e) => setDeletePassword(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition-all pr-10"
                    placeholder="Masukkan password..."
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowDeletePassword(!showDeletePassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                  >
                    {showDeletePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {deleteError && <p className="text-red-500 text-xs mt-2">{deleteError}</p>}
              </div>
              
              <div className="flex justify-end gap-3 mt-8">
                <button
                  type="button"
                  onClick={() => {
                    setDeleteConfirmation(null);
                    setDeletePassword('');
                    setDeleteError('');
                    setShowDeletePassword(false);
                  }}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Batal
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
                >
                  Ya, Hapus
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Sub-component for editable cells
interface EditableCellProps {
  value: string;
  field: keyof ShoppingItem;
  item: ShoppingItem;
  isEditMode: boolean;
  isLocked: boolean;
  onFocus: (id: string, field: string) => void;
  onBlur: (id: string, field: string) => void;
  onChange: (id: string, field: keyof ShoppingItem, value: string) => void;
}

function EditableCell({ value, field, item, isEditMode, isLocked, onFocus, onBlur, onChange }: EditableCellProps) {
  const [localValue, setLocalValue] = useState(value);
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    if (!isEditMode || isLocked) return;
    setIsFocused(true);
    setLocalValue(value);
    onFocus(item.id, field);
  };

  const handleBlur = () => {
    if (!isEditMode || isLocked) return;
    setIsFocused(false);
    onBlur(item.id, field);
    if (localValue !== value) {
      onChange(item.id, field, localValue);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalValue(e.target.value);
    // Optionally emit changes immediately for real-time typing effect
    onChange(item.id, field, e.target.value);
  };

  const displayValue = isFocused ? localValue : value;

  return (
    <td className={`p-0 border-r border-slate-200 relative transition-colors
      ${isLocked ? 'bg-red-50/50' : ''}
      ${isFocused ? 'bg-blue-50/30' : ''}
    `}>
      {isEditMode ? (
        <div className="relative w-full h-full flex items-center">
          <input
            type="text"
            value={displayValue}
            onChange={handleChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
            disabled={isLocked}
            className={`w-full h-full p-2 sm:p-3 bg-transparent outline-none text-xs sm:text-sm
              ${isLocked ? 'cursor-not-allowed text-slate-500' : ''}
              ${isFocused ? 'ring-2 ring-inset ring-blue-500 z-10' : ''}
            `}
            placeholder={isLocked ? '' : '...'}
          />
          {isLocked && (
            <div className="absolute right-2 top-1/2 -translate-y-1/2 group">
              <Lock className="w-3 h-3 text-red-400" />
              <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-max bg-slate-800 text-white text-[10px] sm:text-xs py-1 px-2 rounded shadow-lg z-20">
                Sedang diketik pengguna lain
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="p-2 sm:p-3 w-full h-full min-h-[36px] sm:min-h-[44px] text-slate-700 text-xs sm:text-sm">
          {value || <span className="text-slate-300 italic">Kosong</span>}
        </div>
      )}
    </td>
  );
}
