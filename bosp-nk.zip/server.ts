import { createServer } from 'http';
import { parse } from 'url';
import next from 'next';
import { Server as SocketIOServer } from 'socket.io';
import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';

interface ShoppingItem {
  id: string;
  order_number: number;
  item_name: string;
  quantity: string;
  class_name: string;
  notes: string;
  purchase_status: 'belum' | 'sudah';
}

const dev = process.env.NODE_ENV !== 'production';
const hostname = '0.0.0.0';
const port = parseInt(process.env.PORT || '3000', 10);
const dir = dev ? process.cwd() : path.resolve(__dirname, '..');
const app = next({ dev, hostname, port, dir });
const handle = app.getRequestHandler();

function setupDb() {
  // Gunakan DATABASE_PATH dari environment variable untuk production
  // Jika tidak ada, gunakan ./database.sqlite untuk lokal
  const dbPath = process.env.DATABASE_PATH || './database.sqlite';
  const db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS shopping_items (
      id TEXT PRIMARY KEY,
      order_number INTEGER,
      item_name TEXT,
      quantity TEXT,
      class_name TEXT,
      notes TEXT,
      purchase_status TEXT DEFAULT 'belum',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Ensure at least one row exists
  const count = db.prepare('SELECT COUNT(*) as count FROM shopping_items').get() as { count: number };
  if (count.count === 0) {
    db.prepare(
      `INSERT INTO shopping_items (id, order_number, item_name, quantity, class_name, notes, purchase_status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(uuidv4(), 1, '', '', '', '', 'belum');
  } else {
    // Cleanup: Re-index order_numbers to fix any duplicates
    const allItems = db.prepare('SELECT id FROM shopping_items ORDER BY order_number ASC, created_at ASC').all() as { id: string }[];
    const updateStmt = db.prepare('UPDATE shopping_items SET order_number = ? WHERE id = ?');
    
    const transaction = db.transaction((items) => {
      items.forEach((item: { id: string }, index: number) => {
        updateStmt.run(index + 1, item.id);
      });
    });
    
    transaction(allItems);
  }

  return db;
}

app.prepare().then(() => {
  const db = setupDb();
  
  const server = createServer(async (req, res) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    try {
      const parsedUrl = parse(req.url!, true);
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error('Error handling request:', err);
      res.statusCode = 500;
      res.end('Internal Server Error');
    }
  });

  const io = new SocketIOServer(server, {
    path: '/api/socket',
    addTrailingSlash: false,
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  const lockedCells = new Map<string, { userId: string, timeout: NodeJS.Timeout }>();

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Send initial data
    const items = db.prepare('SELECT * FROM shopping_items ORDER BY order_number ASC').all();
    socket.emit('initial_data', items);

    socket.on('update_cell', (data) => {
      const { id, field, value } = data;
      try {
        db.prepare(
          `UPDATE shopping_items SET ${field} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`
        ).run(value, id);
        socket.broadcast.emit('cell_updated', { id, field, value });

        // Auto-add new row if the last row is now non-empty
        const lastItem = db.prepare('SELECT * FROM shopping_items ORDER BY order_number DESC LIMIT 1').get() as ShoppingItem;
        if (lastItem && (
          (lastItem.item_name && lastItem.item_name.trim() !== '') || 
          (lastItem.quantity && lastItem.quantity.trim() !== '') || 
          (lastItem.class_name && lastItem.class_name.trim() !== '')
        )) {
          const newId = uuidv4();
          const newOrderNumber = lastItem.order_number + 1;
          db.prepare(
            `INSERT INTO shopping_items (id, order_number, item_name, quantity, class_name, notes, purchase_status)
             VALUES (?, ?, '', '', '', '', 'belum')`
          ).run(newId, newOrderNumber);
          
          io.emit('row_added', { 
            id: newId, 
            order_number: newOrderNumber, 
            item_name: '', 
            quantity: '', 
            class_name: '', 
            notes: '', 
            purchase_status: 'belum' 
          });
        }
      } catch (err) {
        console.error('Error updating cell:', err);
      }
    });

    socket.on('delete_item', (data) => {
      const { id } = data;
      try {
        db.prepare('DELETE FROM shopping_items WHERE id = ?').run(id);
        
        // Re-index order_numbers
        const allItems = db.prepare('SELECT id FROM shopping_items ORDER BY order_number ASC, created_at ASC').all() as { id: string }[];
        const updateStmt = db.prepare('UPDATE shopping_items SET order_number = ? WHERE id = ?');
        const transaction = db.transaction((items) => {
          items.forEach((item: { id: string }, index: number) => {
            updateStmt.run(index + 1, item.id);
          });
        });
        transaction(allItems);

        // Ensure at least one row exists
        if (allItems.length === 0) {
          const newId = uuidv4();
          db.prepare(
            `INSERT INTO shopping_items (id, order_number, item_name, quantity, class_name, notes, purchase_status)
             VALUES (?, ?, '', '', '', '', 'belum')`
          ).run(newId, 1);
        }

        const updatedItems = db.prepare('SELECT * FROM shopping_items ORDER BY order_number ASC').all();
        io.emit('initial_data', updatedItems);
      } catch (err) {
        console.error('Error deleting item:', err);
      }
    });

    socket.on('delete_all', () => {
      try {
        db.prepare('DELETE FROM shopping_items').run();
        
        // Ensure at least one row exists
        const newId = uuidv4();
        db.prepare(
          `INSERT INTO shopping_items (id, order_number, item_name, quantity, class_name, notes, purchase_status)
           VALUES (?, ?, '', '', '', '', 'belum')`
        ).run(newId, 1);

        const updatedItems = db.prepare('SELECT * FROM shopping_items ORDER BY order_number ASC').all();
        io.emit('initial_data', updatedItems);
      } catch (err) {
        console.error('Error deleting all items:', err);
      }
    });

    socket.on('lock_cell', (data) => {
      const { id, field, userId } = data;
      const cellKey = `${id}_${field}`;
      
      if (lockedCells.has(cellKey)) {
        clearTimeout(lockedCells.get(cellKey)!.timeout);
      }

      const timeout = setTimeout(() => {
        lockedCells.delete(cellKey);
        io.emit('cell_unlocked', { id, field });
      }, 5000);

      lockedCells.set(cellKey, { userId, timeout });
      socket.broadcast.emit('cell_locked', { id, field, userId });
    });

    socket.on('unlock_cell', (data) => {
      const { id, field } = data;
      const cellKey = `${id}_${field}`;
      
      if (lockedCells.has(cellKey)) {
        clearTimeout(lockedCells.get(cellKey)!.timeout);
        lockedCells.delete(cellKey);
        socket.broadcast.emit('cell_unlocked', { id, field });
      }
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      // Clean up locks for this user if we stored socket.id mapped to userId
      for (const [key, value] of lockedCells.entries()) {
        if (value.userId === socket.id) {
          clearTimeout(value.timeout);
          lockedCells.delete(key);
          const [id, field] = key.split('_');
          io.emit('cell_unlocked', { id, field });
        }
      }
    });
  });

  server.listen(port, '0.0.0.0', () => {
    console.log(`> Ready on http://0.0.0.0:${port}`);
  });
});
