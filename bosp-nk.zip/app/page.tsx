import { cookies } from 'next/headers';
import ShoppingTable from '@/components/ShoppingTable';

export default async function Home() {
  const cookieStore = await cookies();
  const isEditMode = cookieStore.has('auth_token');

  return (
    <main className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-900">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-col md:flex-row justify-between items-center md:items-start mb-6 md:mb-8 gap-4 text-center md:text-left">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Daftar Belanja Barang</h1>
            <p className="text-slate-500 text-sm mt-1">Dana BOSP SD IT Nurul Kautsar</p>
          </div>
        </header>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <ShoppingTable initialEditMode={isEditMode} />
        </div>
      </div>
    </main>
  );
}
